class CategoryItem {
  final String image;
  final String title;
  final String subTitle;
  final bool   isLiked;
  final String channelCounter;

  CategoryItem({
    required this.image,
    required this.title,
    required this.subTitle,
    required this.isLiked,
    required this.channelCounter
  });
}

final categories = [
  CategoryItem(
    image: 'assets/categories/pic1.png',
    title: 'Sports',
    subTitle: 'discover the bets sport\'s channels in the world',
    isLiked: true,
    channelCounter: '30 channels'
  ),
  CategoryItem(
    image: 'assets/categories/pic2.png',
    title: 'Sports',
    subTitle: 'discover the bets sport\'s channels in the world',
    isLiked: true,
    channelCounter: '30 channels'
  ),
  CategoryItem(
    image: 'assets/categories/pic3.png',
    title: 'Sports',
    subTitle: 'discover the bets sport\'s channels in the world',
    isLiked: true,
    channelCounter: '30 channels'
  ),
  CategoryItem(
    image: 'assets/categories/pic4.png',
    title: 'Sports',
    subTitle: 'discover the bets sport\'s channels in the world',
    isLiked: true,
    channelCounter: '30 channels'
  ),
];