import 'package:btl_kiemtra_flutter/extensions/text_style_ext.dart';
import 'package:btl_kiemtra_flutter/shared/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {

  int activePage = 0;
  final PageController _pageController = PageController(viewportFraction: 1.0, initialPage: 0);
  final List<String> images = [
    "https://lumiere-a.akamaihd.net/v1/images/p_avengersendgame_19751_e14a0104.jpeg",
    "https://moviereviewmom.com/wp-content/uploads/2019/05/John-Wick-3-movie-poster.jpeg",
    "https://lumiere-a.akamaihd.net/v1/images/p_avengersendgame_19751_e14a0104.jpeg",
    "https://moviereviewmom.com/wp-content/uploads/2019/05/John-Wick-3-movie-poster.jpeg",
    "https://moviereviewmom.com/wp-content/uploads/2019/05/John-Wick-3-movie-poster.jpeg",
    "https://moviereviewmom.com/wp-content/uploads/2019/05/John-Wick-3-movie-poster.jpeg",
  ];

  TextStyle get _style => TextStyle(fontSize: 18);
  late var topItems = [];

  @override
  void initState() {
    topItems = [
      Text('Featured', style: _style),
      Text('New Release', style: _style),
      Text('Series', style: _style),
    ];
    super.initState();
  }

  final List<Tab> _tabs = const [
    Tab(text: 'Featured'),
    Tab(text: 'New Release'),
    Tab(text: 'Series'),
  ];

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: topItems.length,
      child: _buildTopSlider(context),
    );
    return Padding(
      padding: const EdgeInsets.all(appPadding),
      child: Column(
        children: [
          Expanded(
            child: _buildTopSlider(context),
          ),
          SizedBox(
            height: MediaQuery.of(context).size.height * 0.20,
            child: _buildBottomSlider(context),
          ),
        ],
      ),
    );
  }
  
  Widget _buildTopSlider(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 40,
          child: TabBarView(
            children: _tabs.map((Tab tab) {
              final String label = tab.text!.toLowerCase();
              return Center(
                child: Text(
                  label,
                  style: const TextStyle().title,
                ),
              );
            }).toList(),
          ),
        ),
        
        Expanded(
          //height: MediaQuery.of(context).size.height * 0.45,
          child: Stack(
            children: [
              PageView.builder(
                itemCount: images.length,
                pageSnapping: true,
                //padEnds: false,
                controller: _pageController,
                onPageChanged: (page) {
                  setState(() {
                    activePage = page;
                  });
                },
                itemBuilder: (BuildContext context, int pagePosition) {
                  return Container(
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        fit: BoxFit.fill,
                        image: NetworkImage(
                          images[pagePosition],
                        )
                      ),
                      borderRadius: const BorderRadius.all(Radius.circular(appRadius)),
                    ),
                  );
                },
              ),
              Positioned.fill(
                child: Align(
                  alignment: Alignment.bottomCenter,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: indicators(images.length,activePage)
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10,),
      ],
    );
  }
  
  Widget _buildBottomSlider(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          margin: const EdgeInsets.symmetric(vertical: 10),
          child: const Text('What to watch', style:  TextStyle(color: colorRed, fontSize: 20)),
        ),
        Expanded(
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: _bottomSliderData.length,
            itemBuilder: (ctx, index) {
              final double marginRight = ((index + 1) == _bottomSliderData.length) ? 0 : 15;
              return Container(
                margin: EdgeInsets.only(right: marginRight),
                width: 105,
                decoration: BoxDecoration(
                  borderRadius: const BorderRadius.all(Radius.circular(appRadius)),
                  image: DecorationImage(
                    fit: BoxFit.fill,
                    image: AssetImage(
                      _bottomSliderData[index],
                    )
                  ),
                ),
              ); 
            },
          ),
        ),
      ],
    );
  }

  List<Widget> indicators(imagesLength, currentIndex) {
    return List<Widget>.generate(imagesLength, (index) {
      return Container(
        margin: const EdgeInsets.only(top: 3, left: 3, right: 3, bottom: 10),
        width: currentIndex == index ? 10 : 7,
        height: currentIndex == index ? 10 : 7,
        decoration: BoxDecoration(
          color: currentIndex == index ? Colors.white : Colors.grey,
          shape: BoxShape.circle
        ),
      );
    });
  }

  List<String> get _bottomSliderData => [
    'assets/113x136/pic1.png',
    'assets/113x136/pic2.png',
    'assets/113x136/pic3.png',
    'assets/113x136/pic1.png',
    'assets/113x136/pic2.png',
    'assets/113x136/pic3.png',
  ];
}