import 'package:flutter/material.dart';

class PlaylistAddScreen extends StatelessWidget {
  const PlaylistAddScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: const Text('playlist add screen'),
    );
  }
}