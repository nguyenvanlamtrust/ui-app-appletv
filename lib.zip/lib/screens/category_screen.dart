import 'package:btl_kiemtra_flutter/data/categories.dart';
import 'package:btl_kiemtra_flutter/extensions/text_style_ext.dart';
import 'package:btl_kiemtra_flutter/shared/constants.dart';
import 'package:flutter/material.dart';

class CategoryScreen extends StatelessWidget {
  const CategoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(appPadding),
      child: Column(
        children: [
          SizedBox(
            height: 40,
            child: _buildTopFilter(context),
          ),
          Expanded(
            child: _buildList(context),
          )
        ],
      ),
    );
  }
  
  Widget _buildTopFilter(BuildContext context) {
    final List<Widget> listFilter = [
      Text('Channels', style: const TextStyle().title),
      Text('Trending', style: const TextStyle().titleWhite),
      Text('Series', style: const TextStyle().titleWhite),
    ];
    return ListView.builder(
      scrollDirection: Axis.horizontal,
      itemCount: listFilter.length,
      itemBuilder: (context, index) {
        final double marginRight = (index + 1) == listFilter.length ? 0 : appMargin;
        return Container(
          margin: EdgeInsets.only(right: marginRight),
          child: listFilter[index],
        );
      },
    );
  }
  
  Widget _buildList(BuildContext context) {
    final items = categories;
    return GridView.builder(
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        mainAxisSpacing: appMargin,
        crossAxisSpacing: appMargin,
        crossAxisCount: 2,
        //childAspectRatio: 0.55,
        mainAxisExtent: 340,
      ),
      itemCount: items.length,
      itemBuilder: (BuildContext context, int index) {
        final item = categories[index];
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          mainAxisSize: MainAxisSize.max,
          children: [
            Container(
              margin: const EdgeInsets.only(bottom: 10),
              width: double.infinity,
              height: 220,
              decoration: BoxDecoration(
                borderRadius: const BorderRadius.all(Radius.circular(appRadius)),
                image: DecorationImage(
                  fit: BoxFit.fill,
                  image: AssetImage(item.image)
                ),
              ),
            ),
            SizedBox(height: 30, child: Text(item.title, style: const TextStyle().itemTitle)),
            SizedBox(height: 40, child: Text(item.subTitle, style: const TextStyle().itemSubTitle)),
            SizedBox(height: 30, child: Text(item.channelCounter, style: const TextStyle().itemChannelCounter)),
          ],
        );
      }
    );
  }
}