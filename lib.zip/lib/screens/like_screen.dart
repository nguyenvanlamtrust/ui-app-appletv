import 'package:flutter/material.dart';

class LikeScreenn extends StatelessWidget {
  const LikeScreenn({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: const Text('like screen'),
    );
  }
}